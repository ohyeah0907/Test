﻿using System;

namespace Exercise
{
    class Triangle : Shape
    {
        private Shape shape;
        private double hight;
        private double bottomEdge;
        private double area;

        public Triangle()
        {
            this.shape = new Shape();
        }

        ~Triangle()
        {
        }

        public override void Input()
        {
            Console.WriteLine("Input the triangle: ");
            shape.Input();
        }

        public override void Output()
        {
            shape.Output();
            this.Calculate();
            Console.WriteLine($"The area of triangle is: {this.area}");
        }

        public void Calculate()
        {
            this.bottomEdge = Math.Abs(shape.P1.X - shape.P2.X);
            this.hight = Math.Abs(shape.P1.Y - shape.P2.Y);
            this.area = (this.hight * this.bottomEdge) / 2;
        }

    }
}