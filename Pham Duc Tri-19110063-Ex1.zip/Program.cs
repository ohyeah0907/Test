﻿using System;

namespace Exercise
{
    class Progrram
    {
        static void Main(string[] args)
        {
            ComplexObject complex = new ComplexObject();
            complex.Input();
            complex.FindCoordinate();
            complex.Output();
        }
    }
}