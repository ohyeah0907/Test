﻿using System;

namespace Exercise
{
    class Rectangle : Shape
    {
        private Shape shape;
        private double length;
        private double width;
        private double area;

        public Rectangle()
        {
            this.shape = new Shape();
        }

        ~Rectangle()
        {
        }

        public override void Input()
        {
            Console.WriteLine("Input the Rectangle: ");
            shape.Input();
        }

        public override void Output()
        {
            shape.Output();
            this.Calculate();
            Console.WriteLine($"The area of rectangle is: {this.area}");
        }

        public void Calculate()
        {
            this.length = Math.Abs(shape.P1.X - shape.P2.X);
            this.width = Math.Abs(shape.P1.Y - shape.P2.Y);
            this.area = this.length * this.width;
        }

    }
}