﻿using System;
using System.Collections.Generic;

namespace Exercise
{
    class ComplexObject : Shape
    {
        public List<Shape> lShape;
        public int num;
        private Point M;
        private Point N;


        public ComplexObject()
        {
            this.lShape = new List<Shape>();
            this.M = new Point();
            this.N = new Point();
        }

        ~ComplexObject()
        {
        }

        public override void Input()
        {
            Console.Write("Input number of lines: ");
            int num0 = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < num0; i++)
            {
                Line line = new Line();
                line.Input();
                this.lShape.Add(line);
            }

            Console.Write("Input number of rectangles: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < num1; i++)
            {
                Rectangle rectangle = new Rectangle();
                rectangle.Input();
                this.lShape.Add(rectangle);
            }

            Console.Write("Input number of triangles: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < num2; i++)
            {
                Triangle triangle = new Triangle();
                triangle.Input();
                this.lShape.Add(triangle);
            }

            this.num = num0 + num1 + num2;
        }

        public override void Output()
        {
            Console.WriteLine($"Number of shapes: {this.num}");
            foreach (Shape shape in this.lShape)
            {
                shape.Output();
            }
            Console.WriteLine($"The coordinate of complex object: M({M.X}, {M.Y}) N({N.X}, {N.Y})");
        }

        public void FindCoordinate()
        {
            double max_X = 0, max_Y = 0, min_X = 0, min_Y = 0;
            int k = 0;

            foreach (Shape shape in this.lShape)
            {
                double x1 = shape.P1.X;
                double y1 = shape.P1.Y;
                double x2 = shape.P2.X;
                double y2 = shape.P2.Y;

                if (k == 0)
                {
                    k++;
                    max_X = x1;
                    max_Y = y1;
                    min_X = x2;
                    min_Y = y2;
                }
                else
                {
                    if (x1 < x2)
                    {
                        double t = x1;
                        x1 = x2;
                        x2 = t;
                    }
                    if (x1 > max_X)
                    {
                        max_X = x1;
                    }
                    if (x2 < min_X)
                    {
                        min_X = x2;
                    }

                    if (y1 < y2)
                    {
                        double t = y1;
                        y1 = y2;
                        y2 = t;
                    }
                    if (y1 > max_Y)
                    {
                        max_Y = y1;
                    }
                    if (y2 < min_Y)
                    {
                        min_Y = y2;
                    }
                }
            }

            this.M.X = max_X;
            this.M.Y = max_Y;
            this.N.X = min_X;
            this.N.Y = min_Y;
        }
    }
}
