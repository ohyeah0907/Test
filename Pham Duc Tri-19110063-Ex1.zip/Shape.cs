﻿using System;

namespace Exercise
{
    class Shape
    {
        protected Point p1;
        protected Point p2;
        protected string color;

        public Point P1
        {
            get { return this.p1; }
            set { this.p1 = value; }
        }

        public Point P2
        {
            get { return this.p2; }
            set { this.p2 = value; }
        }

        public string Color
        {
            get { return this.Color; }
            set { this.Color = value; }
        }

        public Shape()
        {
            this.p1 = new Point();
            this.p2 = new Point();
        }

        public Shape(Point p1, Point p2)
        {
            this.p1 = p1;
            this.p2 = p2;
        }

        ~Shape()
        {
        }

        public virtual void Input()
        {
            Console.WriteLine("Input point p1: ");
            this.p1.Input();
            Console.WriteLine("Input point p2: ");
            this.p2.Input();
            Console.Write("Input color of shape: ");
            this.color = Console.ReadLine();
        }

        public void Input(Point p1, Point p2)
        {
            this.p1 = p1;
            this.p2 = p2;
        }

        public virtual void Output()
        {
            Console.WriteLine($"Coordinate A({p1.X}, {p1.Y}): ");
            Console.WriteLine($"Coordinate B({p2.X}, {p2.Y}): ");
            Console.WriteLine($"The color of shape: {this.color}");
        }

        public void Move()
        {
            Console.Write("Input new coordinate x1: ");
            int new_X = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input new coordinate y1: ");
            int new_Y = Convert.ToInt32(Console.ReadLine());

            double dif_X = Math.Abs(p1.X - new_X);
            double dif_Y = Math.Abs(p1.Y - new_Y);

            if (new_X > p1.X)
            {
                p2.X += dif_X;
                p2.Y += dif_Y;
            }
            if (new_X < p1.X)
            {
                p2.X -= dif_X;
                p2.Y -= dif_Y;
            }
        }

        public void ChangeColor()
        {
            Console.Write("Which color do you want to change: ");
            this.color = Console.ReadLine();
        }
    }
}