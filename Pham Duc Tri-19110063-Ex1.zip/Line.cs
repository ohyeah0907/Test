﻿using System;

namespace Exercise
{
    class Line : Shape
    {
        private Shape shape;
        private double length;

        public Line()
        {
            this.shape = new Shape();
        }

        ~Line()
        {
        }

        public override void Input()
        {
            Console.WriteLine("Input the line: ");
            shape.Input();
        }

        public override void Output()
        {
            shape.Output();
            this.Calculate();
            Console.WriteLine($"The length of line is: {this.length}");
        }

        public void Calculate()
        {
            this.length = Math.Sqrt(Math.Pow(shape.P1.X - shape.P2.X, 2) + Math.Pow(shape.P1.Y - shape.P2.Y, 2));
        }

    }
}
